All Star Bulk Order Block v1.1.9

GitHub-managed production release for All Star Embroidery.

Highlights:
- Gutenberg bulk-order block with editable workflow content and styles.
- Supplier Sync compatible with SanMar, S&S Activewear, Momentec, and multi-supplier Woo variations.
- Server-side variation refresh/validation before cart submission.
- Atomic cart rollback if any selected variation fails.
- Detailed cart failure messages instead of generic HTTP 500 responses.
- GitHub manifest updater with automatic WordPress plugin updates.
- Post-checkout artwork workflow remains separate and supported.

Release source:
https://github.com/rolejarczyk/ASE.SupplierSync-Releases/tree/main/asbo


v1.1.1 mobile UX improvements:
- Hides the redundant large expanded-product hero image on screens 767px and below.
- Keeps one product accordion open at a time on mobile to reduce long-page drift.
- Fits the full per-piece pricing matrix inside the mobile viewport without horizontal swiping.
- Tightens mobile spacing, typography, tier messaging, and decoration controls while preserving desktop styling.


v1.1.2 compact ordering workflow:
- Sticky bottom summary/action bar is visible from Intro through checkout preparation.
- Product accordions are single-open on desktop, tablet, and mobile to reduce scroll buildup.
- Large permanent expanded-product hero/details area is replaced by an on-demand Product Details modal with image, description, garment specifications, and size information.
- Product rows, expanded panels, pricing sections, option grids, and sticky summary are more compact across all viewport sizes.
- Pricing now includes a 1+ normal-price tier sourced from the WooCommerce product/variation price when the first configured bulk tier starts above 1.
- Checkout/cart pricing uses the same normal-price fallback below the first bulk threshold, including mixed variation base prices.
- Sticky summary adds Total Saved: volume savings plus $15 digitizing savings at the artwork threshold and $9.99 shipping savings at the shipping threshold by default.
- Savings label and incentive dollar values can be customized in the Gutenberg block sidebar.
- Existing Supplier Sync compatibility for SanMar, S&S Activewear, Momentec, and multi-supplier variations remains intact.


v1.1.3 readability and artwork guidance:
- Responsive clamp()-based typography keeps compact layouts readable across desktop, tablet, and mobile.
- Sticky summary bar is rendered visible from Step 1, before JavaScript initialization.
- Adds one-time 30-second inactivity arrow cue above the current sticky Continue action.
- Reworks Artwork step into two visually guided tasks with clearer selected-state color.
- Logged-in customers can select from their recent WooCommerce orders when reusing approved artwork; guests retain manual reference entry.


v1.1.4 pricing integrity with Supplier Sync 2.0.26+:
- WooCommerce Regular Price is the authoritative customer-facing 1+ price.
- Legacy 1: entries in _asbo_pricing_matrix are ignored; established bulk tiers above 1 are unchanged.
- ASBO never derives customer pricing from unit_buy_price, supplier price_breaks, MAP, MSRP, suggested retail, or list price.
- Total Saved uses Woo Regular Price as the normal-price baseline.
- Checkout now fails clearly when a selected item is missing Woo Regular Price and directs admins to Supplier Sync Quick Repair.
- Removed the old purchasability bypass for blank supplier variation prices now that Supplier Sync standardizes Woo Regular Price.
- Supplier price_breaks remain private and are never rendered by ASBO; only the customer-facing ASBO pricing matrix is displayed.


v1.1.5 stitch-count pricing communication:
- Clarifies that standard embroidery pricing includes up to 10,000 stitches per design.
- Adds a compact, non-alarming 10K stitch allowance note beside per-piece embroidery pricing.
- Adds a fuller 10K Stitch Allowance explanation in the Artwork step, including that any additional embroidery charge is communicated before production begins.
- Updates the production review fine print to use the same customer-facing stitch-count policy.
- Adds matching Gutenberg editor previews for the policy.
- No pricing calculations, checkout rules, stitch-count automation, supplier data, or ASBO discount tiers changed.


v1.1.6 launch ordering polish:
- Adds a customer-visible Starting at price to every collapsed product row, sourced only from Woo Regular Price and the customer-facing ASBO pricing matrix.
- Strengthens the selected decoration method with a gold border and checkmark in addition to the existing dark active background.
- Adds a lightweight subcategory filter when the ASBO block is scoped to a WooCommerce parent category. Only represented direct child categories of that configured parent are shown, so a Headwear/Hats block never surfaces Shirt/Apparel filters.
- Filtering happens instantly without a page reload and automatically closes a product accordion if it becomes hidden by the selected filter.
- Existing pricing calculations, Supplier Sync cost architecture, 10K stitch policy, cart behavior, and checkout workflow are unchanged.


v1.1.7 product-details discoverability polish:
- Adds a muted Details & sizing chip directly beside the product title on desktop and directly beneath it on mobile.
- The chip opens the existing product-details/size-information modal without expanding the pricing accordion first.
- Keeps the full product row as a separate keyboard-accessible accordion control; the details chip is a separate native button, avoiding nested interactive controls.
- Removes the redundant Product details & size information link from the expanded pricing panel.
- Uses a low-contrast warm-neutral chip with navy text, a soft gray border, and restrained gold focus treatment so it remains readable without competing with primary yellow actions.
- No pricing, Supplier Sync, cart, artwork, savings, or checkout calculations changed.


v1.1.8 responsive pricing-matrix fix and updater migration:
- Prevents pricing values from overlapping on tablet/mobile by preserving readable column widths and enabling controlled horizontal scrolling.
- Keeps the Decoration method column visible while swiping quantity tiers.
- Migrates the built-in updater to All-Star-Embroidery/asbo-releases.
- No pricing values, discount tiers, Supplier Sync logic, cart, savings, artwork, or checkout behavior changed.


v1.1.9 artwork review workflow:
- Consolidates the post-checkout artwork uploader into ASBO while preserving the existing protected file storage and WooCommerce order metadata.
- Replaces the customer-facing upload box with one state-aware Artwork component on Thank You and My Account > Orders > View.
- Adds artwork statuses: Artwork Needed, Awaiting Review, Changes Requested, and Approved.
- Emails WooCommerce new-order recipients when new or revised artwork is submitted.
- Adds a native ASBO Artwork Review panel to WooCommerce orders with file preview/download, customer notes, review history, Approve Artwork, and Request Changes.
- Approval emails the customer and records the action in WooCommerce Order Notes.
- Request Changes requires a reason, emails the customer with a direct re-upload link, and records the review in the order history.
- Revised uploads return the order to Awaiting Review and notify the team again.
- Adds an Artwork status column to classic and HPOS WooCommerce order lists.
- Reuses the legacy _ase_order_artwork_files, _ase_artwork_status, and _ase_artwork_customer_notes metadata so existing uploads remain available.
- If the old Code Snippets uploader is still active, ASBO suppresses its duplicate customer/admin panels during migration.
- Pricing, Supplier Sync, bulk tiers, cart totals, 10K stitch calculations, and checkout behavior are unchanged.
