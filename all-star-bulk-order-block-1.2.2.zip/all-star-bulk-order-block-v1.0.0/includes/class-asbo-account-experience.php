<?php
/**
 * All Star My Account experience layered on top of WooCommerce.
 *
 * Keeps the native WooCommerce endpoints and functionality intact while
 * improving information architecture, artwork discoverability and styling.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class ASBO_Account_Experience {
    private const ENDPOINT = 'artwork';
    private const ENDPOINT_VERSION_OPTION = 'asbo_account_endpoint_version';
    private const ENDPOINT_VERSION = '1.1.0';

    public static function boot(): void {
        if ( did_action( 'plugins_loaded' ) ) {
            self::init();
            return;
        }

        add_action( 'plugins_loaded', array( __CLASS__, 'init' ), 25 );
    }

    public static function init(): void {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        add_action( 'init', array( __CLASS__, 'register_endpoint' ), 7 );
        add_action( 'init', array( __CLASS__, 'maybe_flush_endpoint_rules' ), 99 );
        add_action( 'wp_loaded', array( __CLASS__, 'prepare_artwork_fallback_view' ), 30 );
        add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'account_menu_items' ), 20 );
        add_filter( 'woocommerce_get_endpoint_url', array( __CLASS__, 'account_endpoint_url' ), 20, 4 );
        add_filter( 'woocommerce_account_menu_item_classes', array( __CLASS__, 'account_menu_item_classes' ), 20, 2 );
        add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( __CLASS__, 'render_artwork_hub' ) );
        add_filter( 'woocommerce_endpoint_' . self::ENDPOINT . '_title', array( __CLASS__, 'artwork_endpoint_title' ), 10, 2 );

        add_filter( 'body_class', array( __CLASS__, 'body_classes' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ), 30 );
        add_action( 'woocommerce_before_account_navigation', array( __CLASS__, 'render_account_identity' ), 5 );
        add_action( 'woocommerce_account_dashboard', array( __CLASS__, 'render_dashboard' ), 5 );
        remove_action( 'woocommerce_account_dashboard', 'woocommerce_account_dashboard', 10 );
        add_action( 'woocommerce_view_order', array( __CLASS__, 'render_view_order_header' ), 1 );

        add_filter( 'woocommerce_my_account_my_orders_columns', array( __CLASS__, 'orders_columns' ), 20 );
        add_action( 'woocommerce_my_account_my_orders_column_asbo_artwork', array( __CLASS__, 'render_orders_artwork_column' ) );
        add_filter( 'woocommerce_my_account_my_orders_actions', array( __CLASS__, 'orders_actions' ), 20, 2 );
    }

    public static function register_endpoint(): void {
        add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
    }

    public static function maybe_flush_endpoint_rules(): void {
        if ( self::ENDPOINT_VERSION === get_option( self::ENDPOINT_VERSION_OPTION ) ) {
            return;
        }

        flush_rewrite_rules( false );
        update_option( self::ENDPOINT_VERSION_OPTION, self::ENDPOINT_VERSION, false );
    }

    private static function is_artwork_fallback_request(): bool {
        return is_user_logged_in()
            && isset( $_GET['asbo-view'] )
            && self::ENDPOINT === sanitize_key( wp_unslash( $_GET['asbo-view'] ) );
    }

    public static function prepare_artwork_fallback_view(): void {
        if ( ! self::is_artwork_fallback_request() ) {
            return;
        }

        // The normal WooCommerce dashboard callback would otherwise render underneath
        // the fallback Artwork view. Remove only that default callback for this request.
        remove_action( 'woocommerce_account_dashboard', 'woocommerce_account_dashboard', 10 );
    }

    public static function account_endpoint_url( string $url, string $endpoint, $value, string $permalink ): string {
        if ( self::ENDPOINT !== $endpoint ) {
            return $url;
        }

        // Query-string fallback makes Artwork work even before permalink rewrite rules
        // have been refreshed by the host/cache layer. The pretty endpoint remains registered.
        return add_query_arg( 'asbo-view', self::ENDPOINT, wc_get_page_permalink( 'myaccount' ) );
    }

    public static function account_menu_item_classes( array $classes, string $endpoint ): array {
        if ( ! self::is_artwork_fallback_request() ) {
            return $classes;
        }

        if ( self::ENDPOINT === $endpoint ) {
            $classes[] = 'is-active';
        } elseif ( 'dashboard' === $endpoint ) {
            $classes = array_values( array_diff( $classes, array( 'is-active' ) ) );
        }

        return array_values( array_unique( $classes ) );
    }

    public static function account_menu_items( array $items ): array {
        if ( isset( $items[ self::ENDPOINT ] ) ) {
            return $items;
        }

        $result = array();
        foreach ( $items as $key => $label ) {
            $result[ $key ] = $label;
            if ( 'orders' === $key ) {
                $result[ self::ENDPOINT ] = __( 'Artwork', 'all-star-bulk-order' );
            }
        }

        if ( ! isset( $result[ self::ENDPOINT ] ) ) {
            $result[ self::ENDPOINT ] = __( 'Artwork', 'all-star-bulk-order' );
        }

        return $result;
    }

    public static function artwork_endpoint_title( string $title, string $endpoint ): string {
        return self::ENDPOINT === $endpoint ? __( 'Artwork', 'all-star-bulk-order' ) : $title;
    }

    public static function body_classes( array $classes ): array {
        if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
            return $classes;
        }

        $classes[] = 'asbo-account-page';
        if ( is_user_logged_in() ) {
            $classes[] = 'asbo-account-logged-in';
            $endpoint = function_exists( 'WC' ) && WC()->query ? (string) WC()->query->get_current_endpoint() : '';
            if ( self::is_artwork_fallback_request() ) {
                $endpoint = self::ENDPOINT;
            }
            $classes[] = $endpoint ? 'asbo-account-endpoint-' . sanitize_html_class( $endpoint ) : 'asbo-account-dashboard';
        } else {
            $classes[] = 'asbo-account-auth';
        }

        return $classes;
    }

    public static function enqueue_styles(): void {
        if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
            return;
        }

        wp_register_style( 'asbo-account-experience', false, array(), '1.2.2' );
        wp_enqueue_style( 'asbo-account-experience' );
        wp_add_inline_style( 'asbo-account-experience', self::css() );
    }

    public static function render_account_identity(): void {
        if ( ! is_user_logged_in() ) {
            return;
        }

        $user = wp_get_current_user();
        $name = $user->display_name ?: $user->user_login;
        $email = sanitize_email( $user->user_email );
        $initials = self::initials( $name );
        ?>
        <div class="asbo-account-identity">
            <div class="asbo-account-avatar" aria-hidden="true"><?php echo esc_html( $initials ); ?></div>
            <div class="asbo-account-identity__copy">
                <span><?php esc_html_e( 'My Account', 'all-star-bulk-order' ); ?></span>
                <strong><?php echo esc_html( $name ); ?></strong>
                <?php if ( $email ) : ?><small><?php echo esc_html( $email ); ?></small><?php endif; ?>
            </div>
            <button type="button" class="asbo-account-menu-toggle" aria-expanded="false" aria-controls="asbo-account-navigation">
                <span><?php esc_html_e( 'Account menu', 'all-star-bulk-order' ); ?></span>
                <span class="asbo-account-menu-toggle__icon" aria-hidden="true"></span>
            </button>
        </div>
        <script>
        (function () {
            function initAsboAccountMenu() {
                var shell = document.querySelector('.asbo-account-page .woocommerce');
                if (!shell) return;
                var nav = shell.querySelector('.woocommerce-MyAccount-navigation');
                var toggle = shell.querySelector('.asbo-account-menu-toggle');
                if (!nav || !toggle || toggle.dataset.asboReady === '1') return;
                toggle.dataset.asboReady = '1';
                nav.id = 'asbo-account-navigation';

                function closeMenu() {
                    shell.classList.remove('asbo-account-menu-open');
                    toggle.setAttribute('aria-expanded', 'false');
                }

                toggle.addEventListener('click', function () {
                    var opening = !shell.classList.contains('asbo-account-menu-open');
                    shell.classList.toggle('asbo-account-menu-open', opening);
                    toggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
                });

                nav.addEventListener('click', function (event) {
                    if (event.target.closest('a') && window.innerWidth < 768) closeMenu();
                });

                window.addEventListener('resize', function () {
                    if (window.innerWidth >= 768) closeMenu();
                }, { passive: true });
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initAsboAccountMenu);
            } else {
                initAsboAccountMenu();
            }
        }());
        </script>
        <?php
    }

    public static function render_dashboard(): void {
        if ( ! is_user_logged_in() ) {
            return;
        }

        if ( self::is_artwork_fallback_request() ) {
            self::render_artwork_hub();
            return;
        }

        $user = wp_get_current_user();
        $first_name = $user->first_name ?: $user->display_name;
        $orders = wc_get_orders(
            array(
                'customer' => get_current_user_id(),
                'limit'    => 5,
                'orderby'  => 'date',
                'order'    => 'DESC',
            )
        );

        $artwork_attention = 0;
        foreach ( $orders as $order ) {
            $status = self::artwork_status( $order );
            if ( in_array( $status, array( 'needed', 'changes_requested', 'awaiting_review' ), true ) && self::order_has_artwork_context( $order ) ) {
                $artwork_attention++;
            }
        }

        ?>
        <section class="asbo-account-dashboard-hero">
            <div>
                <span class="asbo-account-kicker"><?php esc_html_e( 'All Star Embroidery', 'all-star-bulk-order' ); ?></span>
                <h2><?php echo esc_html( sprintf( __( 'Welcome back, %s.', 'all-star-bulk-order' ), $first_name ) ); ?></h2>
                <p><?php esc_html_e( 'Track orders, review artwork progress, update account details, and keep your next embroidery project moving.', 'all-star-bulk-order' ); ?></p>
            </div>
            <a class="asbo-account-primary-link" href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'View orders', 'all-star-bulk-order' ); ?> <span aria-hidden="true">→</span></a>
        </section>

        <div class="asbo-account-quick-grid">
            <?php self::quick_card( __( 'Orders', 'all-star-bulk-order' ), (string) wc_get_customer_order_count( get_current_user_id() ), __( 'View order history and current production status.', 'all-star-bulk-order' ), wc_get_account_endpoint_url( 'orders' ), '01' ); ?>
            <?php self::quick_card( __( 'Artwork', 'all-star-bulk-order' ), (string) $artwork_attention, 1 === $artwork_attention ? __( 'order currently needs artwork attention.', 'all-star-bulk-order' ) : __( 'orders currently need artwork attention.', 'all-star-bulk-order' ), wc_get_account_endpoint_url( self::ENDPOINT ), '02' ); ?>
            <?php self::quick_card( __( 'Addresses', 'all-star-bulk-order' ), __( 'Manage', 'all-star-bulk-order' ), __( 'Keep billing and shipping details ready for checkout.', 'all-star-bulk-order' ), wc_get_account_endpoint_url( 'edit-address' ), '03' ); ?>
            <?php self::quick_card( __( 'Account details', 'all-star-bulk-order' ), __( 'Profile', 'all-star-bulk-order' ), __( 'Update your name, email, and password securely.', 'all-star-bulk-order' ), wc_get_account_endpoint_url( 'edit-account' ), '04' ); ?>
        </div>

        <?php if ( $orders ) : ?>
            <section class="asbo-account-recent">
                <div class="asbo-account-section-heading">
                    <div><span class="asbo-account-kicker"><?php esc_html_e( 'Recent activity', 'all-star-bulk-order' ); ?></span><h3><?php esc_html_e( 'Recent orders', 'all-star-bulk-order' ); ?></h3></div>
                    <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'View all', 'all-star-bulk-order' ); ?> →</a>
                </div>
                <div class="asbo-account-order-cards">
                    <?php foreach ( $orders as $order ) : self::render_dashboard_order_card( $order ); endforeach; ?>
                </div>
            </section>
        <?php endif;
    }

    private static function quick_card( string $title, string $value, string $description, string $url, string $index ): void {
        ?>
        <a class="asbo-account-quick-card" href="<?php echo esc_url( $url ); ?>">
            <span class="asbo-account-quick-card__index"><?php echo esc_html( $index ); ?></span>
            <strong><?php echo esc_html( $title ); ?></strong>
            <b><?php echo esc_html( $value ); ?></b>
            <p><?php echo esc_html( $description ); ?></p>
            <span class="asbo-account-quick-card__arrow" aria-hidden="true">→</span>
        </a>
        <?php
    }

    private static function render_dashboard_order_card( WC_Order $order ): void {
        $date = $order->get_date_created();
        $artwork = self::artwork_status( $order );
        ?>
        <a class="asbo-account-order-card" href="<?php echo esc_url( $order->get_view_order_url() ); ?>">
            <div class="asbo-account-order-card__top">
                <strong><?php echo esc_html( sprintf( __( 'Order #%s', 'all-star-bulk-order' ), $order->get_order_number() ) ); ?></strong>
                <span class="asbo-account-order-status"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
            </div>
            <div class="asbo-account-order-card__meta">
                <span><?php echo $date ? esc_html( wc_format_datetime( $date ) ) : ''; ?></span>
                <span><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></span>
            </div>
            <?php if ( self::order_has_artwork_context( $order ) ) : ?>
                <div class="asbo-account-order-card__artwork">
                    <span><?php esc_html_e( 'Artwork', 'all-star-bulk-order' ); ?></span>
                    <?php self::status_badge( $artwork ); ?>
                </div>
            <?php endif; ?>
        </a>
        <?php
    }

    public static function render_artwork_hub(): void {
        if ( ! is_user_logged_in() ) {
            return;
        }

        $orders = wc_get_orders(
            array(
                'customer' => get_current_user_id(),
                'limit'    => 50,
                'orderby'  => 'date',
                'order'    => 'DESC',
            )
        );

        $artwork_orders = array_values(
            array_filter(
                $orders,
                static function ( $order ) {
                    return $order instanceof WC_Order && self::order_has_artwork_context( $order );
                }
            )
        );
        ?>
        <section class="asbo-artwork-hub">
            <div class="asbo-account-page-header">
                <div>
                    <span class="asbo-account-kicker"><?php esc_html_e( 'Project files', 'all-star-bulk-order' ); ?></span>
                    <h2><?php esc_html_e( 'Artwork', 'all-star-bulk-order' ); ?></h2>
                    <p><?php esc_html_e( 'See exactly where artwork stands for each order. Upload revisions, review requested changes, and confirm when artwork is approved for production.', 'all-star-bulk-order' ); ?></p>
                </div>
            </div>

            <div class="asbo-artwork-status-guide" aria-label="<?php esc_attr_e( 'Artwork status guide', 'all-star-bulk-order' ); ?>">
                <span><?php esc_html_e( 'Artwork Needed', 'all-star-bulk-order' ); ?></span>
                <span><?php esc_html_e( 'Awaiting Review', 'all-star-bulk-order' ); ?></span>
                <span><?php esc_html_e( 'Changes Requested', 'all-star-bulk-order' ); ?></span>
                <span><?php esc_html_e( 'Approved', 'all-star-bulk-order' ); ?></span>
            </div>

            <?php if ( ! $artwork_orders ) : ?>
                <div class="asbo-account-empty-state">
                    <span aria-hidden="true">✦</span>
                    <h3><?php esc_html_e( 'No artwork activity yet', 'all-star-bulk-order' ); ?></h3>
                    <p><?php esc_html_e( 'Orders that use the All Star artwork workflow will appear here automatically.', 'all-star-bulk-order' ); ?></p>
                    <a class="asbo-account-primary-link" href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'View your orders', 'all-star-bulk-order' ); ?> →</a>
                </div>
            <?php else : ?>
                <div class="asbo-artwork-hub__list">
                    <?php foreach ( $artwork_orders as $order ) : self::render_artwork_hub_card( $order ); endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <?php
    }

    private static function render_artwork_hub_card( WC_Order $order ): void {
        $status = self::artwork_status( $order );
        $files = self::artwork_files( $order );
        $date = $order->get_date_created();
        $cta = 'changes_requested' === $status ? __( 'Upload revision', 'all-star-bulk-order' ) : ( 'needed' === $status ? __( 'Add artwork', 'all-star-bulk-order' ) : __( 'View artwork', 'all-star-bulk-order' ) );
        ?>
        <article class="asbo-artwork-hub-card asbo-artwork-hub-card--<?php echo esc_attr( $status ); ?>">
            <div class="asbo-artwork-hub-card__accent" aria-hidden="true"></div>
            <div class="asbo-artwork-hub-card__body">
                <div class="asbo-artwork-hub-card__heading">
                    <div>
                        <span><?php echo esc_html( sprintf( __( 'Order #%s', 'all-star-bulk-order' ), $order->get_order_number() ) ); ?></span>
                        <h3><?php echo esc_html( self::artwork_status_headline( $status ) ); ?></h3>
                    </div>
                    <?php self::status_badge( $status ); ?>
                </div>
                <p><?php echo esc_html( self::artwork_status_description( $status ) ); ?></p>
                <div class="asbo-artwork-hub-card__meta">
                    <span><b><?php esc_html_e( 'Order date', 'all-star-bulk-order' ); ?></b><?php echo $date ? esc_html( wc_format_datetime( $date ) ) : '—'; ?></span>
                    <span><b><?php esc_html_e( 'Files', 'all-star-bulk-order' ); ?></b><?php echo esc_html( (string) count( $files ) ); ?></span>
                    <span><b><?php esc_html_e( 'Order status', 'all-star-bulk-order' ); ?></b><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
                </div>
            </div>
            <a class="asbo-artwork-hub-card__action" href="<?php echo esc_url( $order->get_view_order_url() . '#asbo-artwork' ); ?>"><?php echo esc_html( $cta ); ?> <span aria-hidden="true">→</span></a>
        </article>
        <?php
    }

    public static function render_view_order_header( $order_id ): void {
        $order = wc_get_order( absint( $order_id ) );
        if ( ! $order instanceof WC_Order ) {
            return;
        }
        ?>
        <section class="asbo-view-order-overview">
            <div>
                <span class="asbo-account-kicker"><?php esc_html_e( 'Order overview', 'all-star-bulk-order' ); ?></span>
                <h2><?php echo esc_html( sprintf( __( 'Order #%s', 'all-star-bulk-order' ), $order->get_order_number() ) ); ?></h2>
            </div>
            <div class="asbo-view-order-overview__statuses">
                <span class="asbo-account-order-status"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
                <?php if ( self::order_has_artwork_context( $order ) ) : self::status_badge( self::artwork_status( $order ) ); endif; ?>
            </div>
        </section>
        <?php
    }

    public static function orders_columns( array $columns ): array {
        if ( isset( $columns['asbo_artwork'] ) ) {
            return $columns;
        }

        $result = array();
        foreach ( $columns as $key => $label ) {
            $result[ $key ] = $label;
            if ( 'order-status' === $key ) {
                $result['asbo_artwork'] = __( 'Artwork', 'all-star-bulk-order' );
            }
        }
        return $result;
    }

    public static function render_orders_artwork_column( WC_Order $order ): void {
        if ( ! self::order_has_artwork_context( $order ) ) {
            echo '<span class="asbo-artwork-order-none">—</span>';
            return;
        }
        self::status_badge( self::artwork_status( $order ) );
    }

    public static function orders_actions( array $actions, WC_Order $order ): array {
        if ( ! self::order_has_artwork_context( $order ) ) {
            return $actions;
        }

        $status = self::artwork_status( $order );
        $label = 'changes_requested' === $status ? __( 'Fix artwork', 'all-star-bulk-order' ) : ( 'needed' === $status ? __( 'Add artwork', 'all-star-bulk-order' ) : __( 'Artwork', 'all-star-bulk-order' ) );
        $actions['asbo-artwork'] = array(
            'url'  => $order->get_view_order_url() . '#asbo-artwork',
            'name' => $label,
        );
        return $actions;
    }

    private static function order_has_artwork_context( WC_Order $order ): bool {
        return (bool) $order->get_meta( '_asbo_artwork_plan', true )
            || (bool) $order->get_meta( '_ase_artwork_status', true )
            || ! empty( self::artwork_files( $order ) );
    }

    private static function artwork_files( WC_Order $order ): array {
        $files = $order->get_meta( '_ase_order_artwork_files', true );
        return is_array( $files ) ? $files : array();
    }

    private static function artwork_status( WC_Order $order ): string {
        if ( class_exists( 'ASBO_Artwork_Review' ) && method_exists( 'ASBO_Artwork_Review', 'get_order_artwork_status' ) ) {
            return ASBO_Artwork_Review::get_order_artwork_status( $order );
        }

        $status = sanitize_key( (string) $order->get_meta( '_ase_artwork_status', true ) );
        if ( 'received' === $status ) {
            return 'awaiting_review';
        }
        if ( in_array( $status, array( 'awaiting_review', 'changes_requested', 'approved' ), true ) ) {
            return $status;
        }
        return self::artwork_files( $order ) ? 'awaiting_review' : 'needed';
    }

    private static function status_badge( string $status ): void {
        $labels = array(
            'needed'            => __( 'Artwork Needed', 'all-star-bulk-order' ),
            'awaiting_review'   => __( 'Awaiting Review', 'all-star-bulk-order' ),
            'changes_requested' => __( 'Changes Requested', 'all-star-bulk-order' ),
            'approved'          => __( 'Approved', 'all-star-bulk-order' ),
        );
        $label = $labels[ $status ] ?? $labels['needed'];
        echo '<span class="asbo-account-artwork-badge asbo-account-artwork-badge--' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
    }

    private static function artwork_status_headline( string $status ): string {
        $copy = array(
            'needed'            => __( 'Artwork is needed for this order', 'all-star-bulk-order' ),
            'awaiting_review'   => __( 'Your artwork is with our review team', 'all-star-bulk-order' ),
            'changes_requested' => __( 'A revision is needed before production', 'all-star-bulk-order' ),
            'approved'          => __( 'Artwork is approved for production', 'all-star-bulk-order' ),
        );
        return $copy[ $status ] ?? $copy['needed'];
    }

    private static function artwork_status_description( string $status ): string {
        $copy = array(
            'needed'            => __( 'Upload the artwork you want us to use so we can review file quality, placement, thread matching, and stitch requirements.', 'all-star-bulk-order' ),
            'awaiting_review'   => __( 'No action is needed right now. We are reviewing the submitted artwork and will contact you before production if anything needs to change.', 'all-star-bulk-order' ),
            'changes_requested' => __( 'Open the order to read the exact review note and submit revised artwork. We will review the revision before production.', 'all-star-bulk-order' ),
            'approved'          => __( 'The reviewed artwork has been cleared for production. We will contact you if any other production detail needs confirmation.', 'all-star-bulk-order' ),
        );
        return $copy[ $status ] ?? $copy['needed'];
    }

    private static function initials( string $name ): string {
        $parts = preg_split( '/\s+/', trim( $name ) ) ?: array();
        $initials = '';
        foreach ( array_slice( $parts, 0, 2 ) as $part ) {
            $initials .= function_exists( 'mb_substr' ) ? mb_substr( $part, 0, 1 ) : substr( $part, 0, 1 );
        }
        return strtoupper( $initials ?: 'AS' );
    }

    private static function css(): string {
        return <<<'CSS'
:root{--asbo-navy:#11192d;--asbo-navy-2:#1b2947;--asbo-gold:#d7aa32;--asbo-gold-soft:#fff8e7;--asbo-ink:#182033;--asbo-muted:#6f7786;--asbo-line:#e5e7eb;--asbo-line-strong:#d4d8df;--asbo-soft:#f7f8fa;--asbo-soft-2:#fbfbfc;--asbo-green:#24734a;--asbo-green-soft:#edf8f2;--asbo-red:#a04435;--asbo-red-soft:#fff3ef;--asbo-warning:#7a5a00;--asbo-warning-soft:#fff8df}
.asbo-account-page .woocommerce{position:relative;left:50%;width:min(1260px,calc(100vw - 48px));max-width:none!important;margin:clamp(34px,5vw,64px) 0 72px!important;transform:translateX(-50%);font-size:15px;color:var(--asbo-ink)}
.asbo-account-page.asbo-account-logged-in .woocommerce{display:grid;grid-template-columns:220px minmax(0,1fr);column-gap:38px;align-items:start}
.asbo-account-page .woocommerce-notices-wrapper,.asbo-account-page .woocommerce-message,.asbo-account-page .woocommerce-error,.asbo-account-page .woocommerce-info{grid-column:1/-1}
.asbo-account-page .woocommerce-MyAccount-navigation{float:none!important;width:auto!important;margin:0!important;border-right:1px solid var(--asbo-line);padding-right:26px}
.asbo-account-page .woocommerce-MyAccount-content{float:none!important;width:auto!important;min-width:0;margin:0!important;padding:0 0 40px;background:transparent!important;border:0!important;border-radius:0!important;box-shadow:none!important}
.asbo-account-identity{grid-column:1/-1;display:flex;align-items:center;gap:12px;margin:0 0 30px;padding:0 0 24px;border-bottom:1px solid var(--asbo-line);background:transparent;color:var(--asbo-ink)}
.asbo-account-avatar{display:grid;place-items:center;flex:0 0 38px;width:38px;height:38px;border-radius:999px;background:var(--asbo-gold-soft);color:#765800;font-size:13px;font-weight:900;border:1px solid #edd892}
.asbo-account-identity__copy{display:grid;gap:1px}.asbo-account-identity__copy>span{color:var(--asbo-muted);font-size:9px;font-weight:850;letter-spacing:.12em;text-transform:uppercase}.asbo-account-identity__copy strong{color:var(--asbo-navy);font-size:14px}.asbo-account-identity__copy small{color:var(--asbo-muted);font-size:11px}
.asbo-account-page .woocommerce-MyAccount-navigation ul{position:sticky;top:140px;display:grid;gap:2px;margin:0!important;padding:0!important;list-style:none!important;background:transparent}
.asbo-account-page .woocommerce-MyAccount-navigation li{margin:0!important;list-style:none!important}
.asbo-account-page .woocommerce-MyAccount-navigation li a{position:relative;display:flex;align-items:center;min-height:39px;padding:8px 12px;border-radius:10px;color:#515b6a!important;font-size:13px;font-weight:700;text-decoration:none!important;transition:background .15s ease,color .15s ease,transform .15s ease}
.asbo-account-page .woocommerce-MyAccount-navigation li a:hover{background:var(--asbo-soft);color:var(--asbo-navy)!important;transform:translateX(2px)}
.asbo-account-page .woocommerce-MyAccount-navigation li.is-active a{background:var(--asbo-gold-soft);color:var(--asbo-navy)!important;font-weight:850}.asbo-account-page .woocommerce-MyAccount-navigation li.is-active a:before{content:"";position:absolute;left:-27px;top:9px;bottom:9px;width:3px;border-radius:99px;background:var(--asbo-gold)}
.asbo-account-kicker{display:block;margin-bottom:7px;color:#8b6a13;font-size:10px;font-weight:900;letter-spacing:.11em;text-transform:uppercase}.asbo-account-page h2,.asbo-account-page h3,.asbo-account-page h4{color:var(--asbo-navy);letter-spacing:-.025em}.asbo-account-page h2{margin:0;font-size:clamp(30px,3.5vw,46px);line-height:1.06}.asbo-account-page h3{font-size:22px}.asbo-account-page p{line-height:1.62}
.asbo-account-dashboard-hero,.asbo-account-page-header,.asbo-account-section-heading,.asbo-view-order-overview{display:flex;align-items:flex-end;justify-content:space-between;gap:28px}
.asbo-account-dashboard-hero{padding:0 0 30px;border-bottom:1px solid var(--asbo-line)}.asbo-account-dashboard-hero>div{max-width:720px}.asbo-account-dashboard-hero p,.asbo-account-page-header p{max-width:720px;margin:11px 0 0;color:var(--asbo-muted);font-size:15px}.asbo-account-primary-link{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:40px;padding:8px 14px;border-radius:11px;background:var(--asbo-navy);color:#fff!important;font-size:12px;font-weight:800;text-decoration:none!important;box-shadow:0 4px 12px rgba(17,25,45,.12)}.asbo-account-primary-link:hover{background:var(--asbo-navy-2);transform:translateY(-1px)}
.asbo-account-quick-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin:0 0 42px;border-bottom:1px solid var(--asbo-line)}.asbo-account-quick-card{position:relative;display:grid;grid-template-columns:1fr auto;grid-template-rows:auto auto;gap:5px 12px;min-height:auto;padding:20px 20px 22px 0;border:0!important;border-right:1px solid var(--asbo-line)!important;border-radius:0!important;background:transparent!important;color:var(--asbo-ink)!important;text-decoration:none!important;box-shadow:none!important}.asbo-account-quick-card:last-child{border-right:0!important;padding-left:20px}.asbo-account-quick-card:not(:first-child){padding-left:20px}.asbo-account-quick-card:hover{background:linear-gradient(to bottom,transparent,rgba(247,248,250,.72))!important}.asbo-account-quick-card__index{display:none}.asbo-account-quick-card strong{grid-column:1;color:var(--asbo-muted);font-size:11px;font-weight:800}.asbo-account-quick-card b{grid-column:1;color:var(--asbo-navy);font-size:22px;font-weight:780;letter-spacing:-.035em}.asbo-account-quick-card p{display:none}.asbo-account-quick-card__arrow{grid-column:2;grid-row:1/3;align-self:center;color:#9ca3af;font-size:18px}.asbo-account-quick-card:hover .asbo-account-quick-card__arrow{color:var(--asbo-gold)}
.asbo-account-section-heading{align-items:center;margin:0 0 12px}.asbo-account-section-heading h3{margin:0}.asbo-account-section-heading a{color:var(--asbo-navy)!important;font-size:12px;font-weight:800;text-decoration:none!important}.asbo-account-order-cards{display:grid;border-top:1px solid var(--asbo-line)}.asbo-account-order-card{display:grid;grid-template-columns:minmax(190px,1fr) auto;gap:8px 22px;padding:18px 2px;border:0!important;border-bottom:1px solid var(--asbo-line)!important;border-radius:0!important;background:transparent!important;color:var(--asbo-ink)!important;text-decoration:none!important;box-shadow:none!important}.asbo-account-order-card:hover{background:linear-gradient(90deg,var(--asbo-soft-2),transparent)!important}.asbo-account-order-card__top{display:flex;align-items:center;gap:10px}.asbo-account-order-card__top strong{color:var(--asbo-navy);font-size:14px}.asbo-account-order-card__meta{grid-row:2;display:flex;gap:14px;color:var(--asbo-muted);font-size:11px}.asbo-account-order-card__artwork{grid-column:2;grid-row:1/3;display:flex;align-items:center;gap:10px}.asbo-account-order-card__artwork>span{color:var(--asbo-muted);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.06em}.asbo-account-order-status,.asbo-account-artwork-badge{display:inline-flex;align-items:center;min-height:26px;padding:4px 9px;border-radius:999px;font-size:10px;font-weight:800;white-space:nowrap}.asbo-account-order-status{background:var(--asbo-soft);color:#586273;border:1px solid var(--asbo-line)}.asbo-account-artwork-badge--needed{background:var(--asbo-soft);color:#596575}.asbo-account-artwork-badge--awaiting_review{background:var(--asbo-warning-soft);color:var(--asbo-warning)}.asbo-account-artwork-badge--changes_requested{background:var(--asbo-red-soft);color:var(--asbo-red)}.asbo-account-artwork-badge--approved{background:var(--asbo-green-soft);color:var(--asbo-green)}
.asbo-account-page-header{align-items:flex-start;margin:0 0 22px;padding:0 0 22px;border-bottom:1px solid var(--asbo-line)}.asbo-artwork-status-guide{display:flex;gap:7px;flex-wrap:wrap;margin:0 0 16px}.asbo-artwork-status-guide span{padding:5px 9px;border:1px solid var(--asbo-line);border-radius:999px;background:#fff;color:var(--asbo-muted);font-size:10px;font-weight:750}.asbo-artwork-hub__list{display:grid;border-top:1px solid var(--asbo-line)}.asbo-artwork-hub-card{position:relative;display:grid;grid-template-columns:5px minmax(0,1fr) auto;border:0!important;border-bottom:1px solid var(--asbo-line)!important;border-radius:0!important;background:transparent!important;overflow:visible!important}.asbo-artwork-hub-card__accent{background:#c6cbd3;border-radius:99px;margin:18px 0}.asbo-artwork-hub-card--awaiting_review .asbo-artwork-hub-card__accent{background:var(--asbo-gold)}.asbo-artwork-hub-card--changes_requested .asbo-artwork-hub-card__accent{background:#c8694f}.asbo-artwork-hub-card--approved .asbo-artwork-hub-card__accent{background:#399063}.asbo-artwork-hub-card__body{padding:18px 20px}.asbo-artwork-hub-card__heading{display:flex;align-items:flex-start;justify-content:space-between;gap:20px}.asbo-artwork-hub-card__heading>div>span{color:var(--asbo-muted);font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}.asbo-artwork-hub-card__heading h3{margin:3px 0 0!important;font-size:18px}.asbo-artwork-hub-card__body>p{max-width:710px;margin:9px 0 14px;color:var(--asbo-muted);font-size:13px}.asbo-artwork-hub-card__meta{display:flex;gap:22px;flex-wrap:wrap}.asbo-artwork-hub-card__meta span{display:flex;flex-direction:column;gap:2px;color:var(--asbo-ink);font-size:11px}.asbo-artwork-hub-card__meta b{color:#9aa1ad;font-size:9px;letter-spacing:.07em;text-transform:uppercase}.asbo-artwork-hub-card__action{display:flex;align-items:center;gap:7px;padding:0 2px 0 20px;color:var(--asbo-navy)!important;font-size:12px;font-weight:850;text-decoration:none!important;white-space:nowrap}.asbo-artwork-hub-card__action:hover{color:#8b6a13!important}.asbo-account-empty-state{padding:44px 0;text-align:left;border-top:1px solid var(--asbo-line);border-bottom:1px solid var(--asbo-line);background:transparent}.asbo-account-empty-state>span{display:none}.asbo-account-empty-state h3{margin:0 0 6px!important}.asbo-account-empty-state p{margin:0 0 16px;max-width:500px;color:var(--asbo-muted)}
.asbo-view-order-overview{align-items:center;margin:0 0 24px;padding:0 0 20px;border-bottom:1px solid var(--asbo-line);background:transparent}.asbo-view-order-overview h2{font-size:26px!important}.asbo-view-order-overview__statuses{display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end}
.asbo-account-page table.shop_table,.asbo-account-page table.woocommerce-table{width:100%!important;border:0!important;border-collapse:collapse!important;border-spacing:0!important;border-radius:0!important;overflow:visible;background:transparent!important}.asbo-account-page table.shop_table thead,.asbo-account-page table.woocommerce-table thead{border-bottom:1px solid var(--asbo-line-strong)}.asbo-account-page table.shop_table th,.asbo-account-page table.woocommerce-table th{padding:11px 10px!important;background:transparent!important;color:#7d8592!important;font-size:10px!important;font-weight:850!important;letter-spacing:.07em;text-transform:uppercase}.asbo-account-page table.shop_table td,.asbo-account-page table.woocommerce-table td{padding:15px 10px!important;border-top:1px solid var(--asbo-line)!important;font-size:13px;vertical-align:middle}.asbo-account-page table.shop_table tbody tr:hover,.asbo-account-page table.woocommerce-table tbody tr:hover{background:var(--asbo-soft-2)}.asbo-account-page .woocommerce-orders-table__cell-order-number a{color:var(--asbo-navy)!important;font-weight:850}.asbo-account-page .woocommerce-orders-table__cell-order-actions .button{margin:2px!important;padding:7px 10px!important;border:1px solid var(--asbo-line-strong)!important;border-radius:9px!important;background:#fff!important;color:var(--asbo-navy)!important;font-size:11px!important;font-weight:750!important}.asbo-account-page .woocommerce-orders-table__cell-order-actions .button:hover{background:var(--asbo-soft)!important}.asbo-account-page .woocommerce-orders-table__cell-order-actions .button.asbo-artwork{border-color:#ead58f!important;background:var(--asbo-gold-soft)!important;color:#6e5205!important}
.asbo-account-page .woocommerce-Addresses{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:0!important;width:100%!important;margin-top:24px!important;align-items:start!important}.asbo-account-page .woocommerce-Addresses:before,.asbo-account-page .woocommerce-Addresses:after{display:none!important}.asbo-account-page .woocommerce-Address,.asbo-account-page .woocommerce-Addresses>.u-column1,.asbo-account-page .woocommerce-Addresses>.u-column2,.asbo-account-page .woocommerce-Addresses>.col-1,.asbo-account-page .woocommerce-Addresses>.col-2{float:none!important;clear:none!important;position:static!important;display:block!important;width:100%!important;max-width:none!important;min-width:0!important;margin:0!important;box-sizing:border-box!important;padding:0 32px 0 0!important;border:0!important;border-radius:0!important;background:transparent!important}.asbo-account-page .woocommerce-Addresses>.u-column2,.asbo-account-page .woocommerce-Addresses>.col-2,.asbo-account-page .woocommerce-Address.col-2{padding:0 0 0 32px!important;border-left:1px solid var(--asbo-line)!important}.asbo-account-page .woocommerce-Address-title{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:15px}.asbo-account-page .woocommerce-Address-title h3{margin:0!important;font-size:24px!important}.asbo-account-page .woocommerce-Address-title a{display:inline-flex;align-items:center;min-height:32px;padding:5px 9px;border-radius:9px;background:var(--asbo-gold-soft);color:#765800!important;font-size:11px;font-weight:800;text-decoration:none!important}.asbo-account-page address{margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;color:var(--asbo-ink)!important;font-style:normal!important;line-height:1.7}
.asbo-account-page form .form-row{margin-bottom:15px}.asbo-account-page form .form-row label{margin-bottom:6px;color:var(--asbo-navy);font-size:12px;font-weight:800}.asbo-account-page form input.input-text,.asbo-account-page form textarea,.asbo-account-page form select,.asbo-account-page .select2-selection{min-height:44px!important;border:1px solid transparent!important;border-radius:11px!important;background:var(--asbo-soft)!important;box-shadow:inset 0 0 0 1px rgba(17,25,45,.03)!important}.asbo-account-page form input.input-text:hover,.asbo-account-page form textarea:hover,.asbo-account-page form select:hover{background:#f3f4f6!important}.asbo-account-page form input.input-text:focus,.asbo-account-page form textarea:focus,.asbo-account-page form select:focus{border-color:#d9bd69!important;background:#fff!important;outline:none!important;box-shadow:0 0 0 3px rgba(215,170,50,.13)!important}.asbo-account-page button.button,.asbo-account-page a.button,.asbo-account-page input.button{min-height:40px;padding:8px 14px!important;border:0!important;border-radius:10px!important;background:var(--asbo-navy)!important;color:#fff!important;font-weight:800!important;box-shadow:0 3px 8px rgba(17,25,45,.12)!important}.asbo-account-page button.button:hover,.asbo-account-page a.button:hover,.asbo-account-page input.button:hover{background:var(--asbo-navy-2)!important}.asbo-account-page fieldset{margin-top:28px;padding:20px 0 0;border:0;border-top:1px solid var(--asbo-line);border-radius:0}.asbo-account-page legend{padding:0 12px 0 0;color:var(--asbo-navy);font-weight:850}
.asbo-account-auth .woocommerce{width:min(980px,calc(100vw - 40px));max-width:none!important}.asbo-account-auth #customer_login{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0;border-top:1px solid var(--asbo-line)}.asbo-account-auth #customer_login>.u-column1,.asbo-account-auth #customer_login>.u-column2{float:none!important;width:auto!important;margin:0!important;padding:30px 36px 0 0!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important}.asbo-account-auth #customer_login>.u-column2{padding-left:36px!important;padding-right:0!important;border-left:1px solid var(--asbo-line)!important}
.asbo-account-page .woocommerce-order-details,.asbo-account-page .woocommerce-customer-details{margin-top:30px;padding-top:6px}.asbo-account-page .woocommerce-order-details__title,.asbo-account-page .woocommerce-column__title{font-size:21px!important}.asbo-account-page .woocommerce-customer-details .woocommerce-columns{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:0!important;border-top:1px solid var(--asbo-line)!important}.asbo-account-page .woocommerce-customer-details .woocommerce-column{float:none!important;clear:none!important;width:100%!important;max-width:none!important;margin:0!important;padding:22px 30px 0 0!important;box-sizing:border-box!important}.asbo-account-page .woocommerce-customer-details .woocommerce-column.col-2{padding-left:30px!important;padding-right:0!important;border-left:1px solid var(--asbo-line)!important}
#asbo-artwork{scroll-margin-top:140px}
@media(max-width:980px){.asbo-account-page.asbo-account-logged-in .woocommerce{grid-template-columns:1fr;column-gap:0}.asbo-account-identity{margin-bottom:12px}.asbo-account-page .woocommerce-MyAccount-navigation{border-right:0;padding-right:0;border-bottom:1px solid var(--asbo-line);padding-bottom:12px;margin-bottom:24px!important}.asbo-account-page .woocommerce-MyAccount-navigation ul{position:static;display:flex;gap:4px;overflow-x:auto;padding:0 0 3px!important;scrollbar-width:thin}.asbo-account-page .woocommerce-MyAccount-navigation li{flex:0 0 auto}.asbo-account-page .woocommerce-MyAccount-navigation li a{min-height:36px;padding:7px 10px;white-space:nowrap}.asbo-account-page .woocommerce-MyAccount-navigation li.is-active a:before{left:10px;right:10px;top:auto;bottom:-13px;width:auto;height:2px}.asbo-account-quick-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.asbo-account-quick-card:nth-child(2){border-right:0!important}.asbo-account-quick-card:nth-child(3){padding-left:0;border-top:1px solid var(--asbo-line)!important}.asbo-account-quick-card:nth-child(4){border-top:1px solid var(--asbo-line)!important}.asbo-artwork-hub-card{grid-template-columns:5px minmax(0,1fr)}.asbo-artwork-hub-card__action{grid-column:2;padding:0 20px 15px}.asbo-account-page .woocommerce-Addresses,.asbo-account-page .woocommerce-customer-details .woocommerce-columns{grid-template-columns:1fr!important}.asbo-account-page .woocommerce-Addresses>.u-column1,.asbo-account-page .woocommerce-Addresses>.u-column2,.asbo-account-page .woocommerce-Addresses>.col-1,.asbo-account-page .woocommerce-Addresses>.col-2,.asbo-account-page .woocommerce-Address{padding:0 0 24px!important;border-left:0!important;border-bottom:1px solid var(--asbo-line)!important}.asbo-account-page .woocommerce-Addresses>.u-column2,.asbo-account-page .woocommerce-Addresses>.col-2,.asbo-account-page .woocommerce-Address.col-2{padding-top:24px!important;border-bottom:0!important}.asbo-account-page .woocommerce-customer-details .woocommerce-column,.asbo-account-page .woocommerce-customer-details .woocommerce-column.col-2{padding:20px 0!important;border-left:0!important;border-bottom:1px solid var(--asbo-line)!important}.asbo-account-page .woocommerce-customer-details .woocommerce-column.col-2{border-bottom:0!important}}
@media(max-width:650px){.asbo-account-page .woocommerce{width:calc(100vw - 24px);margin-top:24px!important}.asbo-account-dashboard-hero,.asbo-account-section-heading,.asbo-account-page-header,.asbo-view-order-overview{align-items:flex-start;flex-direction:column}.asbo-account-dashboard-hero .asbo-account-primary-link{width:auto}.asbo-account-quick-grid{grid-template-columns:1fr}.asbo-account-quick-card,.asbo-account-quick-card:not(:first-child),.asbo-account-quick-card:last-child{padding:14px 0!important;border-right:0!important;border-top:1px solid var(--asbo-line)!important}.asbo-account-quick-card:first-child{border-top:0!important}.asbo-account-order-card{grid-template-columns:1fr}.asbo-account-order-card__artwork{grid-column:1;grid-row:auto;justify-content:flex-start}.asbo-artwork-hub-card__heading{flex-direction:column;gap:8px}.asbo-artwork-hub-card__meta{gap:12px}.asbo-artwork-hub-card__meta span{min-width:42%}.asbo-account-page table.shop_table,.asbo-account-page table.woocommerce-table{display:block}.asbo-account-page table.shop_table thead,.asbo-account-page table.woocommerce-table thead{display:none}.asbo-account-page table.shop_table tbody,.asbo-account-page table.woocommerce-table tbody{display:grid}.asbo-account-page table.shop_table tr,.asbo-account-page table.woocommerce-table tr{display:block;padding:12px 0;border-bottom:1px solid var(--asbo-line);background:transparent}.asbo-account-page table.shop_table td,.asbo-account-page table.woocommerce-table td{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:6px 0!important;border:0!important;text-align:right!important}.asbo-account-page table.shop_table td:before,.asbo-account-page table.woocommerce-table td:before{float:none!important;color:var(--asbo-muted);font-size:10px;font-weight:850;letter-spacing:.05em;text-transform:uppercase}.asbo-account-page .woocommerce-orders-table__cell-order-actions{display:block!important;text-align:left!important}.asbo-account-auth #customer_login{grid-template-columns:1fr}.asbo-account-auth #customer_login>.u-column1,.asbo-account-auth #customer_login>.u-column2{padding:22px 0!important;border-left:0!important;border-bottom:1px solid var(--asbo-line)!important}.asbo-account-auth #customer_login>.u-column2{border-bottom:0!important}}

/* ========================================================================== 
   ASBO 1.2.2 BRAND SYSTEM — All Star Embroidery 2026
   Mobile-first, production/editorial account UI. This intentionally replaces
   the previous HeroUI/SaaS visual language without replacing WooCommerce.
   ========================================================================== */
:root{
  --ase-navy:#080F1F;
  --ase-gold:#D2A952;
  --ase-cream:#F3EEE7;
  --ase-white:#FFFFFF;
  --ase-steel:#B8B6B5;
  --ase-red:#B4383D;
  --ase-ink:#151A24;
  --ase-muted:#626872;
  --ase-line:#DEDAD4;
  --ase-line-dark:#BDB8B1;
  --ase-focus:rgba(210,169,82,.28);
  --ase-radius:6px;
}

/* Never break out of the WordPress/WooCommerce content width. The old 100vw +
   translate shell is intentionally neutralized because it caused mobile/theme
   overflow and made the account page dependent on its parent container. */
.asbo-account-page .woocommerce,
.asbo-account-page .woocommerce *{box-sizing:border-box}
.asbo-account-page .woocommerce{
  position:static!important;
  left:auto!important;
  width:100%!important;
  max-width:1180px!important;
  min-width:0!important;
  margin:clamp(28px,4vw,64px) auto 76px!important;
  padding:0 clamp(20px,3vw,40px)!important;
  transform:none!important;
  color:var(--ase-ink);
  font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
  font-size:16px;
  line-height:1.55;
}
.asbo-account-page.asbo-account-logged-in .woocommerce{
  display:grid!important;
  grid-template-columns:minmax(0,1fr)!important;
  gap:0!important;
  align-items:start;
}
.asbo-account-page .woocommerce-MyAccount-content,
.asbo-account-page .woocommerce-MyAccount-navigation,
.asbo-account-page .asbo-account-identity{min-width:0!important;max-width:100%}
.asbo-account-page .woocommerce-MyAccount-content{
  float:none!important;
  width:100%!important;
  margin:0!important;
  padding:24px 0 0!important;
  border:0!important;
  border-top:2px solid var(--ase-gold)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
  overflow-wrap:anywhere;
}
.asbo-account-page .woocommerce-MyAccount-content img{max-width:100%;height:auto}
.asbo-account-page .woocommerce-MyAccount-content table{max-width:100%}

/* Account identity + navigation: one crafted navy rail, not stacked cards. */
.asbo-account-identity{
  display:grid!important;
  grid-template-columns:48px minmax(0,1fr) auto;
  align-items:center;
  gap:13px;
  margin:0!important;
  padding:16px!important;
  border:0!important;
  border-radius:var(--ase-radius)!important;
  background:var(--ase-navy)!important;
  color:var(--ase-white)!important;
  box-shadow:none!important;
}
.asbo-account-avatar{
  display:grid;
  place-items:center;
  width:48px!important;
  height:48px!important;
  min-width:48px;
  border:1px solid var(--ase-gold)!important;
  border-radius:50%!important;
  background:transparent!important;
  color:var(--ase-gold)!important;
  font-size:13px;
  font-weight:800;
  letter-spacing:.04em;
}
.asbo-account-identity__copy{min-width:0}
.asbo-account-identity__copy>span{
  display:block;
  margin:0 0 2px;
  color:var(--ase-gold)!important;
  font-size:10px!important;
  font-weight:800!important;
  letter-spacing:.14em!important;
  text-transform:uppercase;
}
.asbo-account-identity__copy strong{
  display:block;
  margin:0!important;
  color:var(--ase-white)!important;
  font-size:15px!important;
  font-weight:750;
  line-height:1.25;
}
.asbo-account-identity__copy small{
  display:block;
  margin-top:3px;
  max-width:100%;
  overflow:visible!important;
  color:#C7CBD3!important;
  font-size:12px!important;
  line-height:1.35;
  text-overflow:clip!important;
  white-space:normal!important;
  overflow-wrap:anywhere;
}
.asbo-account-menu-toggle{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  gap:9px;
  min-width:44px;
  min-height:44px;
  padding:0 4px 0 10px;
  border:0;
  border-left:1px solid rgba(255,255,255,.16);
  border-radius:0;
  background:transparent;
  color:var(--ase-white);
  font:inherit;
  font-size:13px;
  font-weight:700;
  cursor:pointer;
}
.asbo-account-menu-toggle__icon{
  width:9px;
  height:9px;
  border-right:2px solid var(--ase-gold);
  border-bottom:2px solid var(--ase-gold);
  transform:rotate(45deg) translateY(-2px);
  transition:transform .18s ease;
}
.asbo-account-menu-toggle[aria-expanded="true"] .asbo-account-menu-toggle__icon{
  transform:rotate(225deg) translate(-2px,-1px);
}
.asbo-account-page .woocommerce-MyAccount-navigation{
  float:none!important;
  width:100%!important;
  margin:0!important;
  padding:0!important;
  border:0!important;
  background:transparent!important;
}
.asbo-account-page .woocommerce-MyAccount-navigation ul{
  position:static!important;
  display:grid!important;
  gap:0!important;
  margin:0!important;
  padding:8px 14px 16px!important;
  overflow:visible!important;
  border:0!important;
  border-radius:0 0 var(--ase-radius) var(--ase-radius)!important;
  background:var(--ase-navy)!important;
  box-shadow:none!important;
  list-style:none!important;
}
.asbo-account-page .woocommerce-MyAccount-navigation li{
  margin:0!important;
  padding:0!important;
  border:0!important;
}
.asbo-account-page .woocommerce-MyAccount-navigation li a{
  position:relative;
  display:flex!important;
  align-items:center;
  min-height:48px!important;
  padding:11px 12px 11px 16px!important;
  border:0!important;
  border-top:1px solid rgba(255,255,255,.08)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
  color:#D7DAE0!important;
  font-size:15px!important;
  font-weight:600!important;
  line-height:1.2;
  text-decoration:none!important;
  transform:none!important;
  white-space:normal!important;
}
.asbo-account-page .woocommerce-MyAccount-navigation li:first-child a{border-top:0!important}
.asbo-account-page .woocommerce-MyAccount-navigation li a:hover,
.asbo-account-page .woocommerce-MyAccount-navigation li a:focus-visible{
  background:rgba(255,255,255,.055)!important;
  color:var(--ase-white)!important;
  transform:none!important;
}
.asbo-account-page .woocommerce-MyAccount-navigation li.is-active a{
  background:transparent!important;
  color:var(--ase-gold)!important;
  font-weight:800!important;
  box-shadow:none!important;
}
.asbo-account-page .woocommerce-MyAccount-navigation li.is-active a:before{
  content:""!important;
  position:absolute!important;
  left:0!important;
  top:10px!important;
  bottom:10px!important;
  width:2px!important;
  height:auto!important;
  border-radius:0!important;
  background:var(--ase-gold)!important;
}
.asbo-account-page .woocommerce-MyAccount-navigation-link--customer-logout{
  margin-top:8px!important;
  padding-top:8px!important;
  border-top:1px solid rgba(210,169,82,.34)!important;
}

/* Editorial type hierarchy. */
.asbo-account-page .woocommerce-MyAccount-content h1,
.asbo-account-page .woocommerce-MyAccount-content h2,
.asbo-account-page .woocommerce-MyAccount-content h3{
  color:var(--ase-navy)!important;
  letter-spacing:-.02em!important;
}
.asbo-account-page .woocommerce-MyAccount-content h2,
.asbo-account-page .asbo-account-page-header h2{
  font-family:"Roboto Slab",Georgia,serif!important;
  font-size:clamp(32px,4vw,46px)!important;
  font-weight:700!important;
  line-height:1.08!important;
}
.asbo-account-page .woocommerce-MyAccount-content h3{font-size:21px!important;line-height:1.25}
.asbo-account-kicker{
  display:block;
  margin-bottom:8px;
  color:#876A2A!important;
  font-size:11px!important;
  font-weight:800!important;
  letter-spacing:.14em!important;
  text-transform:uppercase;
}
.asbo-account-page .woocommerce-MyAccount-content>p,
.asbo-account-page .asbo-account-page-header p,
.asbo-account-page .asbo-account-dashboard-hero p{
  color:var(--ase-muted)!important;
  font-size:16px!important;
  line-height:1.6!important;
}

/* Dashboard: information strip, not a grid of chatbot cards. */
.asbo-account-dashboard-hero{
  display:flex!important;
  align-items:flex-end!important;
  justify-content:space-between!important;
  gap:28px!important;
  padding:4px 0 30px!important;
  border:0!important;
  border-bottom:1px solid var(--ase-line)!important;
  background:transparent!important;
}
.asbo-account-dashboard-hero h2{margin:0 0 12px!important}
.asbo-account-primary-link{
  display:inline-flex!important;
  align-items:center;
  justify-content:center;
  min-height:46px!important;
  padding:10px 17px!important;
  border:1px solid var(--ase-navy)!important;
  border-radius:5px!important;
  background:var(--ase-navy)!important;
  color:var(--ase-white)!important;
  box-shadow:none!important;
  font-size:14px!important;
  font-weight:750!important;
  text-decoration:none!important;
  transform:none!important;
}
.asbo-account-primary-link:hover{background:#111A2C!important;transform:none!important}
.asbo-account-quick-grid{
  display:grid!important;
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  gap:0!important;
  margin:30px 0 44px!important;
  border-top:1px solid var(--ase-line)!important;
  border-bottom:1px solid var(--ase-line)!important;
}
.asbo-account-quick-card{
  position:relative;
  display:flex!important;
  min-height:166px!important;
  flex-direction:column;
  padding:22px!important;
  border:0!important;
  border-left:1px solid var(--ase-line)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
  color:var(--ase-ink)!important;
  text-decoration:none!important;
  transform:none!important;
}
.asbo-account-quick-card:first-child{border-left:0!important}
.asbo-account-quick-card:hover{background:var(--ase-cream)!important;box-shadow:none!important;transform:none!important}
.asbo-account-quick-card__index{margin-bottom:20px!important;color:#8A6C2A!important;font-size:10px!important;font-weight:800!important;letter-spacing:.14em!important}
.asbo-account-quick-card strong{color:var(--ase-navy)!important;font-size:14px!important}
.asbo-account-quick-card b{margin:6px 0 9px!important;color:var(--ase-navy)!important;font-size:28px!important;line-height:1!important}
.asbo-account-quick-card p{margin:0!important;color:var(--ase-muted)!important;font-size:13px!important;line-height:1.45!important}
.asbo-account-quick-card__arrow{right:18px!important;bottom:17px!important;color:#8A6C2A!important}

/* Natural lists and production records. */
.asbo-account-section-heading,
.asbo-account-page-header,
.asbo-view-order-overview{
  display:flex!important;
  align-items:flex-end!important;
  justify-content:space-between!important;
  gap:24px!important;
}
.asbo-account-page-header{
  align-items:flex-start!important;
  padding:0 0 28px!important;
  border:0!important;
  border-bottom:1px solid var(--ase-line)!important;
}
.asbo-account-order-cards{display:grid!important;gap:0!important;border-top:1px solid var(--ase-line)!important}
.asbo-account-order-card{
  display:block!important;
  padding:19px 4px!important;
  border:0!important;
  border-bottom:1px solid var(--ase-line)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
  color:inherit!important;
  text-decoration:none!important;
}
.asbo-account-order-card:hover{background:var(--ase-cream)!important;border-color:var(--ase-line)!important}
.asbo-account-order-card__top strong{color:var(--ase-navy)!important;font-size:15px!important}
.asbo-account-order-card__meta{color:var(--ase-muted)!important;font-size:13px!important}
.asbo-account-order-card__artwork{border-top:1px solid #ECE8E2!important;color:var(--ase-muted)!important;font-size:11px!important}

/* Statuses are production labels, not rounded app chips. */
.asbo-account-order-status,
.asbo-account-artwork-badge{
  display:inline-flex!important;
  align-items:center;
  min-height:26px!important;
  padding:4px 8px!important;
  border:1px solid transparent!important;
  border-radius:3px!important;
  font-size:10px!important;
  font-weight:800!important;
  line-height:1.2!important;
  letter-spacing:.04em;
  text-transform:uppercase;
  white-space:nowrap;
}
.asbo-account-order-status{border-color:var(--ase-line)!important;background:transparent!important;color:#59606A!important}
.asbo-account-artwork-badge--needed{border-color:var(--ase-line-dark)!important;background:transparent!important;color:#545A63!important}
.asbo-account-artwork-badge--awaiting_review{border-color:#D9BD78!important;background:#FBF6E9!important;color:#725824!important}
.asbo-account-artwork-badge--changes_requested{border-color:#D9A5A8!important;background:#FCF2F2!important;color:var(--ase-red)!important}
.asbo-account-artwork-badge--approved{border-color:var(--ase-navy)!important;background:var(--ase-navy)!important;color:var(--ase-white)!important}
.asbo-artwork-status-guide{display:none!important}

/* Artwork hub = production tickets separated by rules. */
.asbo-artwork-hub__list{display:grid!important;gap:0!important;margin-top:8px;border-top:1px solid var(--ase-line)!important}
.asbo-artwork-hub-card{
  position:relative;
  display:grid!important;
  grid-template-columns:3px minmax(0,1fr) auto!important;
  overflow:visible!important;
  border:0!important;
  border-bottom:1px solid var(--ase-line)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
}
.asbo-artwork-hub-card__accent{background:var(--ase-steel)!important}
.asbo-artwork-hub-card--awaiting_review .asbo-artwork-hub-card__accent{background:var(--ase-gold)!important}
.asbo-artwork-hub-card--changes_requested .asbo-artwork-hub-card__accent{background:var(--ase-red)!important}
.asbo-artwork-hub-card--approved .asbo-artwork-hub-card__accent{background:var(--ase-navy)!important}
.asbo-artwork-hub-card__body{padding:24px 24px 24px 20px!important}
.asbo-artwork-hub-card__heading{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:20px!important}
.asbo-artwork-hub-card__heading>div>span{color:var(--ase-muted)!important;font-size:11px!important;font-weight:800!important;letter-spacing:.08em!important;text-transform:uppercase}
.asbo-artwork-hub-card__heading h3{margin:4px 0 0!important;font-family:"Roboto Slab",Georgia,serif!important;font-size:20px!important}
.asbo-artwork-hub-card__body>p{max-width:720px!important;margin:11px 0 18px!important;color:var(--ase-muted)!important;font-size:14px!important;line-height:1.6!important}
.asbo-artwork-hub-card__meta{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:14px 24px!important}
.asbo-artwork-hub-card__meta span{display:flex!important;min-width:0;flex-direction:column;gap:3px;color:var(--ase-ink)!important;font-size:12px!important;overflow-wrap:anywhere}
.asbo-artwork-hub-card__meta b{color:#777B83!important;font-size:9px!important;font-weight:800!important;letter-spacing:.1em!important;text-transform:uppercase}
.asbo-artwork-hub-card__action{
  align-self:center;
  display:flex!important;
  align-items:center;
  min-height:44px!important;
  margin:0 4px 0 0!important;
  padding:10px 14px!important;
  border:0!important;
  border-radius:0!important;
  background:transparent!important;
  color:var(--ase-navy)!important;
  font-size:13px!important;
  font-weight:800!important;
  text-decoration:none!important;
  white-space:nowrap;
}
.asbo-artwork-hub-card__action:hover{background:var(--ase-cream)!important;text-decoration:underline!important;text-underline-offset:3px}

/* Empty states stay editorial and restrained. */
.asbo-account-empty-state{
  padding:48px 0!important;
  border:0!important;
  border-bottom:1px solid var(--ase-line)!important;
  border-radius:0!important;
  background:transparent!important;
  text-align:left!important;
}
.asbo-account-empty-state>span{display:none!important}
.asbo-account-empty-state h3{font-family:"Roboto Slab",Georgia,serif!important}

/* WooCommerce tables: clean order records on desktop; true reflow on phones. */
.asbo-account-page table.shop_table,
.asbo-account-page table.woocommerce-table{
  width:100%!important;
  max-width:100%!important;
  border:0!important;
  border-top:1px solid var(--ase-line)!important;
  border-bottom:1px solid var(--ase-line)!important;
  border-collapse:collapse!important;
  border-spacing:0!important;
  border-radius:0!important;
  overflow:visible!important;
  background:transparent!important;
  box-shadow:none!important;
}
.asbo-account-page table.shop_table th,
.asbo-account-page table.woocommerce-table th{
  padding:12px 12px!important;
  border:0!important;
  border-bottom:1px solid var(--ase-line)!important;
  background:var(--ase-cream)!important;
  color:#5C6068!important;
  font-size:10px!important;
  font-weight:800!important;
  letter-spacing:.09em!important;
  text-transform:uppercase;
}
.asbo-account-page table.shop_table td,
.asbo-account-page table.woocommerce-table td{
  padding:16px 12px!important;
  border:0!important;
  border-top:1px solid #ECE8E2!important;
  background:transparent!important;
  font-size:14px!important;
  vertical-align:middle!important;
}
.asbo-account-page .woocommerce-orders-table__cell-order-actions .button{
  min-height:40px!important;
  margin:2px!important;
  padding:8px 11px!important;
  border:1px solid var(--ase-line-dark)!important;
  border-radius:4px!important;
  background:transparent!important;
  color:var(--ase-navy)!important;
  box-shadow:none!important;
  font-size:12px!important;
  font-weight:700!important;
}
.asbo-account-page .woocommerce-orders-table__cell-order-actions .button.asbo-artwork{
  border-color:var(--ase-gold)!important;
  background:#FBF6E9!important;
  color:#6F5520!important;
}

/* Forms + addresses: borders and rules before cards/shadows. */
.asbo-account-page form .form-row label{margin-bottom:7px!important;color:var(--ase-navy)!important;font-size:13px!important;font-weight:750!important}
.asbo-account-page form input.input-text,
.asbo-account-page form textarea,
.asbo-account-page form select,
.asbo-account-page .select2-selection{
  width:100%;
  min-height:48px!important;
  max-width:100%;
  border:1px solid var(--ase-line-dark)!important;
  border-radius:5px!important;
  background:var(--ase-white)!important;
  box-shadow:none!important;
  color:var(--ase-ink)!important;
  font-size:16px!important;
}
.asbo-account-page form textarea{min-height:120px!important;padding:12px!important}
.asbo-account-page form input.input-text:focus,
.asbo-account-page form textarea:focus,
.asbo-account-page form select:focus{
  border-color:var(--ase-gold)!important;
  outline:2px solid var(--ase-focus)!important;
  outline-offset:1px!important;
  box-shadow:none!important;
}
.asbo-account-page button.button,
.asbo-account-page a.button,
.asbo-account-page input.button{
  min-height:46px!important;
  padding:10px 16px!important;
  border:1px solid var(--ase-navy)!important;
  border-radius:5px!important;
  background:var(--ase-navy)!important;
  color:var(--ase-white)!important;
  box-shadow:none!important;
  font-size:14px!important;
  font-weight:750!important;
}
.asbo-account-page fieldset{
  margin-top:28px!important;
  padding:22px 0 0!important;
  border:0!important;
  border-top:1px solid var(--ase-line)!important;
  border-radius:0!important;
}
.asbo-account-page legend{padding:0 10px 0 0!important;color:var(--ase-navy)!important;font-weight:800!important}
.asbo-account-page .woocommerce-Addresses,
.asbo-account-page .woocommerce-customer-details .woocommerce-columns{
  display:grid!important;
  grid-template-columns:repeat(2,minmax(0,1fr))!important;
  gap:32px!important;
}
.asbo-account-page .woocommerce-Address,
.asbo-account-page .woocommerce-customer-details .woocommerce-column{
  float:none!important;
  clear:none!important;
  position:static!important;
  width:100%!important;
  min-width:0!important;
  margin:0!important;
  padding:18px 0 0!important;
  border:0!important;
  border-top:2px solid var(--ase-gold)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
}
.asbo-account-page address{
  margin-top:14px!important;
  padding:0!important;
  border:0!important;
  border-radius:0!important;
  background:transparent!important;
  color:var(--ase-ink)!important;
  font-style:normal!important;
  line-height:1.7!important;
}

/* Order overview and customer artwork flow become part of the page, not widgets. */
.asbo-view-order-overview{
  align-items:center!important;
  margin:0 0 28px!important;
  padding:0 0 20px!important;
  border:0!important;
  border-bottom:1px solid var(--ase-line)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
}
.asbo-account-page #asbo-artwork.asbo-artwork-customer{
  margin:38px 0 0!important;
  padding:26px 0 0!important;
  border:0!important;
  border-top:2px solid var(--ase-gold)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
}
#asbo-artwork{scroll-margin-top:120px}

/* Auth screens use the same material language without becoming two floating cards. */
.asbo-account-auth .woocommerce{max-width:980px!important}
.asbo-account-auth #customer_login{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:48px!important}
.asbo-account-auth #customer_login>.u-column1,
.asbo-account-auth #customer_login>.u-column2{
  float:none!important;
  width:auto!important;
  margin:0!important;
  padding:24px 0 0!important;
  border:0!important;
  border-top:2px solid var(--ase-gold)!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
}

/* Tablet is deliberately its own layout — not a stretched phone. */
@media (min-width:768px){
  .asbo-account-page.asbo-account-logged-in .woocommerce{
    grid-template-columns:clamp(190px,22vw,248px) minmax(0,1fr)!important;
    grid-template-areas:"identity content" "nav content"!important;
    column-gap:clamp(30px,4vw,56px)!important;
    row-gap:0!important;
  }
  .asbo-account-identity{
    grid-area:identity;
    grid-template-columns:48px minmax(0,1fr)!important;
    padding:22px 18px 18px!important;
    border-radius:var(--ase-radius) var(--ase-radius) 0 0!important;
  }
  .asbo-account-menu-toggle{display:none!important}
  .asbo-account-page .woocommerce-MyAccount-navigation{
    grid-area:nav;
    align-self:start;
  }
  .asbo-account-page .woocommerce-MyAccount-navigation ul{
    padding:6px 14px 18px!important;
    border-radius:0 0 var(--ase-radius) var(--ase-radius)!important;
  }
  .asbo-account-page .woocommerce-MyAccount-navigation li a{
    min-height:44px!important;
    padding:10px 10px 10px 16px!important;
    font-size:13px!important;
  }
  .asbo-account-page .woocommerce-MyAccount-content{grid-area:content;padding-top:24px!important}
}

@media (min-width:768px) and (max-width:1099px){
  .asbo-account-page .woocommerce{padding:0 28px!important}
  .asbo-account-page.asbo-account-logged-in .woocommerce{
    grid-template-columns:190px minmax(0,1fr)!important;
    column-gap:30px!important;
  }
  .asbo-account-quick-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .asbo-account-quick-card{border-left:0!important;border-top:1px solid var(--ase-line)!important}
  .asbo-account-quick-card:nth-child(odd){border-right:1px solid var(--ase-line)!important}
  .asbo-account-quick-card:nth-child(-n+2){border-top:0!important}
  .asbo-artwork-hub-card{grid-template-columns:3px minmax(0,1fr)!important}
  .asbo-artwork-hub-card__action{grid-column:2!important;justify-self:start;margin:0 0 20px 20px!important;padding:8px 0!important}
}

/* Mobile reflows. Nothing horizontally scrolls just to preserve desktop UI. */
@media (max-width:767px){
  .asbo-account-page .woocommerce{
    display:block!important;
    width:100%!important;
    margin:24px auto 56px!important;
    padding:0 20px!important;
    font-size:16px!important;
  }
  .asbo-account-identity{margin:0 0 18px!important}
  .asbo-account-page .woocommerce-MyAccount-navigation{display:none!important;margin:-18px 0 24px!important}
  .asbo-account-page .woocommerce.asbo-account-menu-open .asbo-account-identity{border-radius:var(--ase-radius) var(--ase-radius) 0 0!important}
  .asbo-account-page .woocommerce.asbo-account-menu-open .woocommerce-MyAccount-navigation{display:block!important}
  .asbo-account-page .woocommerce-MyAccount-navigation ul{display:grid!important;overflow:visible!important;padding-top:4px!important}
  .asbo-account-page .woocommerce-MyAccount-content{padding-top:22px!important}
  .asbo-account-page .woocommerce-MyAccount-content h2,
  .asbo-account-page .asbo-account-page-header h2{font-size:34px!important}
  .asbo-account-dashboard-hero,
  .asbo-account-section-heading,
  .asbo-account-page-header,
  .asbo-view-order-overview{
    align-items:flex-start!important;
    flex-direction:column!important;
    gap:16px!important;
  }
  .asbo-account-dashboard-hero{padding-bottom:24px!important}
  .asbo-account-dashboard-hero .asbo-account-primary-link{width:100%!important}
  .asbo-account-quick-grid{grid-template-columns:1fr!important;margin:24px 0 36px!important}
  .asbo-account-quick-card{
    min-height:0!important;
    padding:18px 4px!important;
    border:0!important;
    border-top:1px solid var(--ase-line)!important;
  }
  .asbo-account-quick-card:first-child{border-top:0!important}
  .asbo-account-quick-card__index{margin-bottom:9px!important}
  .asbo-account-quick-card p{display:block!important;max-width:88%;font-size:14px!important}
  .asbo-account-order-card{padding:18px 0!important}
  .asbo-account-order-card__top,
  .asbo-account-order-card__meta,
  .asbo-account-order-card__artwork{align-items:flex-start!important;flex-direction:column!important;gap:7px!important}
  .asbo-artwork-hub-card{grid-template-columns:3px minmax(0,1fr)!important}
  .asbo-artwork-hub-card__body{padding:20px 0 14px 16px!important}
  .asbo-artwork-hub-card__heading{flex-direction:column!important;gap:9px!important}
  .asbo-artwork-hub-card__body>p{font-size:15px!important}
  .asbo-artwork-hub-card__meta{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:13px!important}
  .asbo-artwork-hub-card__action{
    grid-column:2!important;
    justify-self:start;
    margin:0 0 18px 16px!important;
    padding:8px 0!important;
  }
  .asbo-account-page table.shop_table,
  .asbo-account-page table.woocommerce-table{display:block!important;border:0!important;background:transparent!important}
  .asbo-account-page table.shop_table thead,
  .asbo-account-page table.woocommerce-table thead{display:none!important}
  .asbo-account-page table.shop_table tbody,
  .asbo-account-page table.woocommerce-table tbody{display:grid!important;gap:0!important}
  .asbo-account-page table.shop_table tr,
  .asbo-account-page table.woocommerce-table tr{
    display:block!important;
    padding:16px 0!important;
    border:0!important;
    border-bottom:1px solid var(--ase-line)!important;
    border-radius:0!important;
    background:transparent!important;
    box-shadow:none!important;
  }
  .asbo-account-page table.shop_table td,
  .asbo-account-page table.woocommerce-table td{
    display:flex!important;
    align-items:flex-start!important;
    justify-content:space-between!important;
    gap:16px!important;
    min-width:0!important;
    padding:7px 0!important;
    border:0!important;
    text-align:right!important;
    overflow-wrap:anywhere;
  }
  .asbo-account-page table.shop_table td:before,
  .asbo-account-page table.woocommerce-table td:before{
    flex:0 0 38%;
    float:none!important;
    color:#777B83!important;
    font-size:10px!important;
    font-weight:800!important;
    letter-spacing:.07em!important;
    text-align:left!important;
    text-transform:uppercase;
  }
  .asbo-account-page .woocommerce-orders-table__cell-order-actions{display:flex!important;flex-wrap:wrap!important;justify-content:flex-start!important;text-align:left!important}
  .asbo-account-page .woocommerce-Addresses,
  .asbo-account-page .woocommerce-customer-details .woocommerce-columns,
  .asbo-account-auth #customer_login{grid-template-columns:1fr!important;gap:28px!important}
  .asbo-account-page .woocommerce-Address,
  .asbo-account-page .woocommerce-customer-details .woocommerce-column{padding-top:16px!important}
}

@media (max-width:420px){
  .asbo-account-page .woocommerce{padding:0 16px!important}
  .asbo-account-identity{grid-template-columns:44px minmax(0,1fr) 44px!important;padding:14px!important}
  .asbo-account-avatar{width:44px!important;height:44px!important;min-width:44px!important}
  .asbo-account-menu-toggle{width:44px!important;padding:0!important;border-left:0!important}
  .asbo-account-menu-toggle>span:first-child{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
  .asbo-artwork-hub-card__meta{grid-template-columns:1fr!important}
}

@media (prefers-reduced-motion:reduce){
  .asbo-account-page *,
  .asbo-account-page *:before,
  .asbo-account-page *:after{scroll-behavior:auto!important;transition:none!important;animation:none!important}
}

CSS;
    }
}
